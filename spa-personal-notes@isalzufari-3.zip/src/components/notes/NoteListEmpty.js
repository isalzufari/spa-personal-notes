import React from 'react';

function NotesListEmpty() {
  return (
    <section className='notes-list-empty'>
      <p className='notes-list__empty'>Anda belum menuangkan keluhan anda...</p>
    </section>
  )
}

export default NotesListEmpty;